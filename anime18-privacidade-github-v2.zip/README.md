# Política de Privacidade - ANIME 18+

Este repositório contém a política de privacidade do aplicativo ANIME 18+.

O conteúdo hospedado neste repositório será usado como política pública conforme exigido pelo Google Play para aplicativos com conteúdo adulto ou sensível.
